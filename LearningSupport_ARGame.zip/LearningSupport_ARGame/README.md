# 注意  

1. 项目gradle的版本取四人中最小为,其中
   - 插件为：com.android.tools.build:gradle:3.1.2
   - gradle版本为：gradle-4.4-all.zip

# 资料  

[功能列表](./function.md)  
[数据库表定义](./database.md)  
[所用到的相关技术](./requiredTechnology.md)  
