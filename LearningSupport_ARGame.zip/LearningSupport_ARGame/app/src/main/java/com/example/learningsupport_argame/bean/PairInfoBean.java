package com.example.learningsupport_argame.bean;

/**
 * 币对信息
 *
 * @author jiang
 * @date 2018/5/16 00:49
 */
public class PairInfoBean  {

    public String pairId;
    public String pairName;
    public String pairUnit;
    public String pairUnitId;

}
